public class TreeSearchHistory implements SearchHistory {	
	public TSHNode root; // Do not change
	public int n; // Do not change

	public TreeSearchHistory() {  // Do not change
		root = new TSHNode();
		n = 0;
	}
	
	// Change the code staring from this point

	@Override
	public int size() {
		return 0;
	}

	@Override
	public void add(String word) {
	}

	@Override
	public boolean findWord(String word) {
		return false;
	}

	@Override
	public boolean findPrefix(String prefix) {
		return false;
	}

	@Override
	public List<String> complete(String prefix) {
		return null;
	}
}
